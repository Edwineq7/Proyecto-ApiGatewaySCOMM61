﻿namespace ApiGateway.PostgreSql
{
    public class Class
    {
    }
}
