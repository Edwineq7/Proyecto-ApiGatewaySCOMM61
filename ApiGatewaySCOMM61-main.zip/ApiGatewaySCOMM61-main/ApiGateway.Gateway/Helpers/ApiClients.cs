﻿namespace ApiGateway.Gateway.Helpers
{
    public enum ApiClients
    {
        SqlServer, //0
        PostgreSql, //1
        MongoDB //2
    }
}
